
package com.tausif.t4app

import androidx.room.*

@Dao
interface HistoryDao{

 @Insert
 suspend fun insert(h:HistoryEntity)

 @Query("SELECT * FROM HistoryEntity ORDER BY id DESC")
 suspend fun getAll():List<HistoryEntity>

 @Query("DELETE FROM HistoryEntity")
 suspend fun deleteAll()
}
