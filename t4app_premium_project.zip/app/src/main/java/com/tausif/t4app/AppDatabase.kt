
package com.tausif.t4app

import android.content.Context
import androidx.room.*

@Database(entities=[HistoryEntity::class],version=1)
abstract class AppDatabase:RoomDatabase(){

 abstract fun dao():HistoryDao

 companion object{

  private var db:AppDatabase?=null

  fun get(c:Context):AppDatabase{

   if(db==null){
    db=Room.databaseBuilder(c,AppDatabase::class.java,"t4.db").build()
   }

   return db!!
  }

 }
}
