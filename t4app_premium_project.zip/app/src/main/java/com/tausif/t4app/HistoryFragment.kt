
package com.tausif.t4app

import android.os.Bundle
import android.view.*
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.io.File

class HistoryFragment: Fragment(){

 lateinit var adapter:HistoryAdapter

 override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{

  val v=i.inflate(R.layout.fragment_history,c,false)

  val rv=v.findViewById<RecyclerView>(R.id.historylist)
  adapter=HistoryAdapter()

  rv.layoutManager=LinearLayoutManager(requireContext())
  rv.adapter=adapter

  load()

  v.findViewById<Button>(R.id.deletehistory).setOnClickListener{
   lifecycleScope.launch{
    AppDatabase.get(requireContext()).dao().deleteAll()
    load()
   }
  }

  v.findViewById<Button>(R.id.exporthistory).setOnClickListener{
   lifecycleScope.launch{

    val data=AppDatabase.get(requireContext()).dao().getAll()
    val file=File(requireContext().getExternalFilesDir(null),"history.csv")
    file.writeText(data.joinToString("\n"){it.userId+","+it.type+","+it.time})

   }
  }

  return v
 }

 fun load(){

  lifecycleScope.launch{
   val data=AppDatabase.get(requireContext()).dao().getAll()
   adapter.setData(data)
  }

 }
}
