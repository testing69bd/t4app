
package com.tausif.t4app

import android.view.*
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HistoryAdapter:RecyclerView.Adapter<HistoryAdapter.VH>(){

 var list:List<HistoryEntity> = listOf()

 class VH(v:View):RecyclerView.ViewHolder(v){
  val t:TextView=v.findViewById(android.R.id.text1)
 }

 override fun onCreateViewHolder(p:ViewGroup,v:Int):VH{
  val view=LayoutInflater.from(p.context).inflate(android.R.layout.simple_list_item_1,p,false)
  return VH(view)
 }

 override fun getItemCount()=list.size

 override fun onBindViewHolder(h:VH,i:Int){
  val d=list[i]
  h.t.text=d.userId+" | "+d.type
 }

 fun setData(d:List<HistoryEntity>){
  list=d
  notifyDataSetChanged()
 }
}
