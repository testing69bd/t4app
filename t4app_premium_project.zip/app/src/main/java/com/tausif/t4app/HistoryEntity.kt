
package com.tausif.t4app

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class HistoryEntity(
 @PrimaryKey(autoGenerate=true) val id:Int,
 val userId:String,
 val type:String,
 val time:Long
)
