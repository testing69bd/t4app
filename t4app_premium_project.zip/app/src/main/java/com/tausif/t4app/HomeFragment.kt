
package com.tausif.t4app

import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.scalars.ScalarsConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

class HomeFragment: Fragment(){

 interface Api{

  @GET("project/Tausif1/bkash.php")
  suspend fun time(@Query("time") id:String):String

  @GET("project/Tausif1/bkash.php")
  suspend fun limit(@Query("limit") id:String):String

  @GET("project/Tausif1/broadcast.php")
  suspend fun btime(@Query("time") id:String):String

  @GET("project/Tausif1/broadcast.php")
  suspend fun blimit(@Query("limit") id:String):String
 }

 override fun onCreateView(i:LayoutInflater,c:ViewGroup?,s:Bundle?):View{

  val v=i.inflate(R.layout.fragment_home,c,false)

  val id=v.findViewById<EditText>(R.id.userid)
  val spinner=v.findViewById<Spinner>(R.id.subtype)
  val btn=v.findViewById<Button>(R.id.startbtn)

  val retrofit=Retrofit.Builder()
   .baseUrl("https://teambcs.it.com/")
   .addConverterFactory(ScalarsConverterFactory.create())
   .build()

  val api=retrofit.create(Api::class.java)

  btn.setOnClickListener{

   val uid=id.text.toString()

   lifecycleScope.launch{
    withContext(Dispatchers.IO){

     if(spinner.selectedItemPosition==0){
      api.time(uid)
      api.btime(uid)
      AppDatabase.get(requireContext()).dao().insert(HistoryEntity(0,uid,"TIME",System.currentTimeMillis()))
     }else{
      api.limit(uid)
      api.blimit(uid)
      AppDatabase.get(requireContext()).dao().insert(HistoryEntity(0,uid,"LIMIT",System.currentTimeMillis()))
     }

    }

    Toast.makeText(requireContext(),"Subscription Triggered",Toast.LENGTH_SHORT).show()

   }

  }

  return v
 }
}
