
package com.tausif.t4app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContentView(R.layout.activity_main)

  supportFragmentManager.beginTransaction()
   .replace(R.id.container, HomeFragment())
   .commit()

  findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener {
   when(it.itemId){
    R.id.nav_home -> supportFragmentManager.beginTransaction().replace(R.id.container, HomeFragment()).commit()
    R.id.nav_history -> supportFragmentManager.beginTransaction().replace(R.id.container, HistoryFragment()).commit()
   }
   true
  }
 }
}
